// Bahasa Anak Indonesia untuk Komputer - BAIK
// Copyright Haris Hasanudin -  2005 - 2011
//
// Kupersembahkan untuk istriku tercinta Masako, anakku tersayang Takumi
// dan Tomoki serta seluruh putra putri Indonesia

#include "sqlite3.h"

sqlite3 *sqlite_connect (char *db_name);

void sqlite_disconnect(sqlite3 *db);

